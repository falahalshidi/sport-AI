import React, { useState } from 'react';
import { Users, Calendar, Settings, FileText, Filter, Download, Brain, Zap } from 'lucide-react';

// Mock data
const mockEvents = [
  {
    id: 1,
    title: 'مؤتمر الشباب العماني 2025',
    description: 'مؤتمر سنوي لتطوير مهارات الشباب العماني',
    date: '2025-03-15',
    location: 'مسقط',
    requiredVolunteers: 100,
    registeredVolunteers: 300,
    category: 'تعليمي'
  },
  {
    id: 2,
    title: 'حملة تنظيف الشواطئ',
    description: 'حملة بيئية لتنظيف شواطئ سلطنة عمان',
    date: '2025-02-20',
    location: 'صحار',
    requiredVolunteers: 50,
    registeredVolunteers: 200,
    category: 'بيئي'
  }
];

// Generate 300 mock volunteers with diverse profiles
const generateMockVolunteers = () => {
  const names = [
    'أحمد بن سالم الهنائي', 'فاطمة بنت محمد الرواحي', 'سعيد بن علي البوسعيدي',
    'مريم بنت خالد الشامسي', 'عبدالله بن أحمد المعمري', 'نورا بنت سعيد الكندي',
    'محمد بن عبدالله الفارسي', 'عائشة بنت علي الحارثي', 'يوسف بن محمد الغافري',
    'زينب بنت سالم العبري', 'خالد بن يوسف الجابري', 'هند بنت عمر الراشدي',
    'عمر بن خالد السالمي', 'سارة بنت أحمد البلوشي', 'طارق بن سعد الحبسي',
    'ليلى بنت محمد الشحي', 'حسام بن علي المقبالي', 'رقية بنت عبدالله الزدجالي',
    'ماجد بن سالم الحراصي', 'أسماء بنت يوسف الكعبي', 'فهد بن عمر الشكيلي',
    'منى بنت خالد الهاشمي', 'راشد بن أحمد الوهيبي', 'دعاء بنت سعيد الجهوري',
    'بدر بن محمد العامري', 'شيخة بنت علي الصوافي', 'سلطان بن عبدالله الحضرمي',
    'وفاء بنت سالم الكلباني', 'جاسم بن يوسف الريامي', 'إيمان بنت عمر الخروصي'
  ];
  
  const cities = ['مسقط', 'صحار', 'نزوى', 'صلالة', 'عبري', 'الرستاق', 'بهلاء', 'إبراء', 'صور', 'خصب'];
  const educationLevels = [
    'دبلوم', 'بكالوريوس إدارة أعمال', 'بكالوريوس هندسة', 'بكالوريوس تربية', 
    'بكالوريوس طب', 'ماجستير إدارة', 'ماجستير علوم اجتماعية', 'ماجستير هندسة',
    'دكتوراه', 'بكالوريوس حاسوب', 'بكالوريوس اقتصاد', 'بكالوريوس قانون'
  ];
  const skillsList = [
    'إدارة المشاريع', 'التواصل', 'القيادة', 'التنظيم', 'التدريب', 'التطوير',
    'التسويق', 'المحاسبة', 'البرمجة', 'التصميم', 'الترجمة', 'الكتابة',
    'التصوير', 'الإعلام', 'الطبخ', 'الإسعافات الأولية', 'اللغات', 'الرياضة'
  ];
  
  const volunteers = [];
  
  for (let i = 1; i <= 300; i++) {
    const age = Math.floor(Math.random() * 30) + 20; // 20-50 years
    const experienceYears = Math.floor(Math.random() * 10) + 1; // 1-10 years
    const name = names[Math.floor(Math.random() * names.length)];
    const city = cities[Math.floor(Math.random() * cities.length)];
    const education = educationLevels[Math.floor(Math.random() * educationLevels.length)];
    const numSkills = Math.floor(Math.random() * 4) + 1; // 1-4 skills
    const skills = [];
    
    for (let j = 0; j < numSkills; j++) {
      const skill = skillsList[Math.floor(Math.random() * skillsList.length)];
      if (!skills.includes(skill)) {
        skills.push(skill);
      }
    }
    
    // AI-based scoring algorithm
    let aiScore = 50; // Base score
    
    // Age factor (25-35 is optimal)
    if (age >= 25 && age <= 35) aiScore += 15;
    else if (age >= 20 && age <= 40) aiScore += 10;
    else aiScore += 5;
    
    // Experience factor
    aiScore += Math.min(experienceYears * 3, 20);
    
    // Education factor
    if (education.includes('دكتوراه')) aiScore += 20;
    else if (education.includes('ماجستير')) aiScore += 15;
    else if (education.includes('بكالوريوس')) aiScore += 10;
    else aiScore += 5;
    
    // Skills factor
    aiScore += skills.length * 3;
    
    // Location preference (local volunteers get bonus)
    if (city === 'مسقط') aiScore += 5;
    
    // Add some randomness for realistic variation
    aiScore += Math.floor(Math.random() * 10) - 5;
    
    // Ensure score is within reasonable range
    aiScore = Math.max(60, Math.min(100, aiScore));
    
    volunteers.push({
      id: i,
      name: `${name} ${i > 30 ? '- ' + i : ''}`,
      age,
      city,
      experience: `خبرة ${experienceYears} ${experienceYears === 1 ? 'سنة' : 'سنوات'} في العمل التطوعي`,
      skills: skills.join(', '),
      education,
      eventId: Math.random() > 0.3 ? 1 : 2, // 70% for event 1, 30% for event 2
      score: aiScore,
      email: `volunteer${i}@example.om`,
      phone: `+968 9${String(Math.floor(Math.random() * 1000000)).padStart(6, '0')}`,
      aiRanking: 0, // Will be calculated
      aiReasons: [] // Will be populated by AI analysis
    });
  }
  
  return volunteers;
};

const mockVolunteers = generateMockVolunteers();

// AI Analysis function
const analyzeVolunteerWithAI = (volunteer, eventRequirements) => {
  const reasons = [];
  let aiScore = volunteer.score;
  
  // AI analysis based on event type
  if (eventRequirements.category === 'تعليمي') {
    if (volunteer.education.includes('تربية') || volunteer.education.includes('ماجستير')) {
      aiScore += 5;
      reasons.push('خلفية تعليمية مناسبة للفعالية');
    }
    if (volunteer.skills.includes('التدريب') || volunteer.skills.includes('التطوير')) {
      aiScore += 5;
      reasons.push('مهارات التدريب والتطوير');
    }
  }
  
  if (eventRequirements.category === 'بيئي') {
    if (volunteer.age <= 35) {
      aiScore += 3;
      reasons.push('عمر مناسب للأنشطة البيئية');
    }
    if (volunteer.city === eventRequirements.location) {
      aiScore += 5;
      reasons.push('إقامة في نفس منطقة الفعالية');
    }
  }
  
  // Experience bonus
  const expMatch = volunteer.experience.match(/(\d+)/);
  const expYears = expMatch ? parseInt(expMatch[1]) : 0;
  if (expYears >= 3) {
    reasons.push('خبرة واسعة في العمل التطوعي');
  }
  
  // Education level analysis
  if (volunteer.education.includes('ماجستير') || volunteer.education.includes('دكتوراه')) {
    reasons.push('مستوى تعليمي عالي');
  }
  
  return {
    ...volunteer,
    aiScore: Math.min(100, aiScore),
    aiReasons: reasons
  };
};

type FilterCriteria = {
  minAge: number;
  maxAge: number;
  city: string;
  minExperienceYears: number;
  education: string;
  skills: string[];
  useAI: boolean;
  aiWeight: number;
};

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [selectedEvent, setSelectedEvent] = useState<number | null>(null);
  const [filters, setFilters] = useState<FilterCriteria>({
    minAge: 18,
    maxAge: 65,
    city: '',
    minExperienceYears: 0,
    education: '',
    skills: [],
    useAI: true,
    aiWeight: 0.7
  });
  const [filteredVolunteers, setFilteredVolunteers] = useState(mockVolunteers);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const applyFilters = async () => {
    setIsAnalyzing(true);
    
    // Simulate AI processing time
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const filtered = mockVolunteers.filter(volunteer => {
      if (selectedEvent && volunteer.eventId !== selectedEvent) return false;
      if (volunteer.age < filters.minAge || volunteer.age > filters.maxAge) return false;
      if (filters.city && !volunteer.city.includes(filters.city)) return false;
      
      // Extract experience years from text
      const experienceMatch = volunteer.experience.match(/(\d+)/);
      const experienceYears = experienceMatch ? parseInt(experienceMatch[1]) : 0;
      if (experienceYears < filters.minExperienceYears) return false;
      
      if (filters.education && !volunteer.education.includes(filters.education)) return false;
      
      return true;
    });
    
    // Apply AI analysis if enabled
    let processedVolunteers = filtered;
    if (filters.useAI && selectedEvent) {
      const event = mockEvents.find(e => e.id === selectedEvent);
      processedVolunteers = filtered.map(volunteer => 
        analyzeVolunteerWithAI(volunteer, event)
      );
      
      // Sort by AI score (highest first)
      processedVolunteers.sort((a, b) => b.aiScore - a.aiScore);
    } else {
      // Sort by regular score
      processedVolunteers.sort((a, b) => b.score - a.score);
    }
    
    setFilteredVolunteers(processedVolunteers);
    setIsAnalyzing(false);
  };

  const exportToCSV = () => {
    if (!selectedEvent) return;
    
    const event = mockEvents.find(e => e.id === selectedEvent);
    const volunteersToExport = filteredVolunteers.slice(0, event?.requiredVolunteers || 100);
    
    const csvContent = [
      ['الاسم', 'العمر', 'المدينة', 'الخبرة', 'المهارات', 'التعليم', 'النقاط', 'البريد الإلكتروني', 'رقم الهاتف'].join(','),
      ...volunteersToExport.map(v => [
        v.name, v.age, v.city, v.experience, v.skills, v.education, 
        filters.useAI ? v.aiScore : v.score, v.email, v.phone
      ].join(','))
    ].join('\n');
    
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `volunteers_${event?.title}_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderDashboard = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">لوحة تحكم الإدارة</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-600 text-sm font-medium">إجمالي الفعاليات</p>
                <p className="text-2xl font-bold text-red-700">{mockEvents.length}</p>
              </div>
              <Calendar className="h-8 w-8 text-red-600" />
            </div>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-600 text-sm font-medium">إجمالي المتطوعين</p>
                <p className="text-2xl font-bold text-green-700">300</p>
              </div>
              <Users className="h-8 w-8 text-green-600" />
            </div>
          </div>
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-600 text-sm font-medium">في انتظار المراجعة</p>
                <p className="text-2xl font-bold text-yellow-700">45</p>
              </div>
              <FileText className="h-8 w-8 text-yellow-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-4">الفعاليات الحالية</h3>
        <div className="space-y-4">
          {mockEvents.map(event => (
            <div key={event.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h4 className="font-bold text-lg text-gray-800">{event.title}</h4>
                  <p className="text-gray-600 mt-1">{event.description}</p>
                  <div className="flex flex-wrap gap-4 mt-3 text-sm text-gray-500">
                    <span>📅 {event.date}</span>
                    <span>📍 {event.location}</span>
                    <span>👥 {event.registeredVolunteers}/{event.requiredVolunteers} متطوع</span>
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded">{event.category}</span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setSelectedEvent(event.id);
                    setCurrentPage('filter');
                  }}
                  className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  فرز المتطوعين
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderFilterPage = () => {
    const event = mockEvents.find(e => e.id === selectedEvent);
    
    return (
      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800">فرز المتطوعين - {event?.title}</h2>
            <button
              onClick={() => setCurrentPage('dashboard')}
              className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg"
            >
              العودة
            </button>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">الحد الأدنى للعمر</label>
              <input
                type="number"
                value={filters.minAge}
                onChange={(e) => setFilters({...filters, minAge: parseInt(e.target.value)})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-red-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">الحد الأقصى للعمر</label>
              <input
                type="number"
                value={filters.maxAge}
                onChange={(e) => setFilters({...filters, maxAge: parseInt(e.target.value)})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-red-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">المدينة</label>
              <select
                value={filters.city}
                onChange={(e) => setFilters({...filters, city: e.target.value})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">جميع المدن</option>
                <option value="مسقط">مسقط</option>
                <option value="صحار">صحار</option>
                <option value="نزوى">نزوى</option>
                <option value="صلالة">صلالة</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">سنوات الخبرة (الحد الأدنى)</label>
              <input
                type="number"
                value={filters.minExperienceYears}
                onChange={(e) => setFilters({...filters, minExperienceYears: parseInt(e.target.value)})}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-red-500 focus:border-red-500"
              />
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-4 mb-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-bold text-blue-800">الفرز بالذكاء الاصطناعي</h4>
                <Brain className="h-6 w-6 text-blue-600" />
              </div>
              <div className="space-y-3">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.useAI}
                    onChange={(e) => setFilters({...filters, useAI: e.target.checked})}
                    className="ml-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <span className="text-sm text-blue-700">تفعيل الفرز الذكي</span>
                </label>
                {filters.useAI && (
                  <div>
                    <label className="block text-xs text-blue-600 mb-1">وزن الذكاء الاصطناعي</label>
                    <input
                      type="range"
                      min="0.1"
                      max="1"
                      step="0.1"
                      value={filters.aiWeight}
                      onChange={(e) => setFilters({...filters, aiWeight: parseFloat(e.target.value)})}
                      className="w-full h-2 bg-blue-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <span className="text-xs text-blue-600">{Math.round(filters.aiWeight * 100)}%</span>
                  </div>
                )}
              </div>
            </div>
            
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-bold text-green-800">معايير الفرز الذكي</h4>
                <Zap className="h-6 w-6 text-green-600" />
              </div>
              <ul className="text-xs text-green-700 space-y-1">
                <li>• تحليل مطابقة المهارات للفعالية</li>
                <li>• تقييم الخبرة والمؤهلات</li>
                <li>• المسافة الجغرافية</li>
                <li>• التوافق مع متطلبات الفعالية</li>
                <li>• تحليل الأداء السابق</li>
              </ul>
            </div>
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={applyFilters}
              disabled={isAnalyzing}
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white px-6 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              {isAnalyzing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  جاري التحليل...
                </>
              ) : (
                <>
                  {filters.useAI ? <Brain className="h-4 w-4" /> : <Filter className="h-4 w-4" />}
                  {filters.useAI ? 'فرز ذكي' : 'تطبيق الفلاتر'}
                </>
              )}
            </button>
            <button
              onClick={exportToCSV}
              disabled={!selectedEvent || filteredVolunteers.length === 0}
              className="bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-6 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              <Download className="h-4 w-4" />
              تصدير CSV ({Math.min(filteredVolunteers.length, event?.requiredVolunteers || 100)})
            </button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-gray-800">
              المتطوعون المفروزون ({filteredVolunteers.length} من أصل {event?.registeredVolunteers})
            </h3>
            <div className="text-sm text-gray-600">
              سيتم اختيار أفضل {event?.requiredVolunteers} متطوع
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  <th className="border border-gray-300 px-4 py-3 text-right">الترتيب</th>
                  <th className="border border-gray-300 px-4 py-3 text-right">الاسم</th>
                  <th className="border border-gray-300 px-4 py-3 text-right">العمر</th>
                  <th className="border border-gray-300 px-4 py-3 text-right">المدينة</th>
                  <th className="border border-gray-300 px-4 py-3 text-right">الخبرة</th>
                  <th className="border border-gray-300 px-4 py-3 text-right">التعليم</th>
                  <th className="border border-gray-300 px-4 py-3 text-right">النقاط</th>
                  {filters.useAI && <th className="border border-gray-300 px-4 py-3 text-right">تحليل الذكاء الاصطناعي</th>}
                  <th className="border border-gray-300 px-4 py-3 text-right">الحالة</th>
                </tr>
              </thead>
              <tbody>
                {filteredVolunteers.map((volunteer, index) => (
                  <tr 
                    key={volunteer.id}
                    className={`${
                      index < (event?.requiredVolunteers || 100) 
                        ? 'bg-green-50 border-green-200' 
                        : 'bg-red-50 border-red-200'
                    } hover:bg-opacity-75 transition-colors`}
                  >
                    <td className="border border-gray-300 px-4 py-3 font-bold">
                      #{index + 1}
                    </td>
                    <td className="border border-gray-300 px-4 py-3 font-medium">
                      {volunteer.name}
                    </td>
                    <td className="border border-gray-300 px-4 py-3">{volunteer.age}</td>
                    <td className="border border-gray-300 px-4 py-3">{volunteer.city}</td>
                    <td className="border border-gray-300 px-4 py-3 text-sm">{volunteer.experience}</td>
                    <td className="border border-gray-300 px-4 py-3 text-sm">{volunteer.education}</td>
                    <td className="border border-gray-300 px-4 py-3">
                      <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded font-bold">
                        {filters.useAI ? volunteer.aiScore || volunteer.score : volunteer.score}
                      </span>
                    </td>
                    {filters.useAI && (
                      <td className="border border-gray-300 px-4 py-3 text-xs">
                        {volunteer.aiReasons && volunteer.aiReasons.length > 0 ? (
                          <ul className="list-disc list-inside text-green-700">
                            {volunteer.aiReasons.slice(0, 2).map((reason, idx) => (
                              <li key={idx}>{reason}</li>
                            ))}
                          </ul>
                        ) : (
                          <span className="text-gray-500">تحليل أساسي</span>
                        )}
                      </td>
                    )}
                    <td className="border border-gray-300 px-4 py-3">
                      {index < (event?.requiredVolunteers || 100) ? (
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-sm font-medium">
                          مقبول
                        </span>
                      ) : (
                        <span className="bg-red-100 text-red-800 px-2 py-1 rounded text-sm font-medium">
                          قائمة انتظار
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <header className="bg-red-600 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="bg-white rounded-full p-2">
                <Users className="h-8 w-8 text-red-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">نظام إدارة المتطوعين</h1>
                <p className="text-red-100 text-sm">سلطنة عمان - وزارة التنمية الاجتماعية</p>
              </div>
            </div>
            
            <nav className="flex space-x-6 space-x-reverse">
              <button
                onClick={() => setCurrentPage('dashboard')}
                className={`flex items-center space-x-2 space-x-reverse px-4 py-2 rounded-lg transition-colors ${
                  currentPage === 'dashboard' 
                    ? 'bg-white text-red-600' 
                    : 'text-white hover:bg-red-700'
                }`}
              >
                <Settings className="h-5 w-5" />
                <span>لوحة التحكم</span>
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentPage === 'dashboard' && renderDashboard()}
        {currentPage === 'filter' && renderFilterPage()}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-lg font-medium">نظام إدارة المتطوعين - سلطنة عمان</p>
            <p className="text-gray-400 mt-2">وزارة التنمية الاجتماعية © 2025</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;